package com.example.android.footballcounter;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    int scoreTeamA;
    int scoreTeamB;
    int foulsForA;
    int foulsForB;
    TextView scoreCount;
    TextView foulsCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void displayForTeamA(int score, int fouls) {
        scoreCount = findViewById(R.id.team_a_score);
        foulsCount = findViewById(R.id.team_a_fouls);
        scoreCount.setText(String.valueOf(score));
        foulsCount.setText(String.valueOf(fouls));
    }

    public void displayForTeamB(int score, int fouls) {
        scoreCount = findViewById(R.id.team__b_score);
        foulsCount = findViewById(R.id.team_b_fouls);
        scoreCount.setText(String.valueOf(score));
        foulsCount.setText(String.valueOf(fouls));
    }

    public void goalForTeamA(View view) {
        scoreTeamA += 1;
        displayForTeamA(scoreTeamA, foulsForA);
    }

    public void foulForA(View view) {
        foulsForA += 1;
        displayForTeamA(scoreTeamA, foulsForA);
    }

    public void goalForTeamB(View view) {
        scoreTeamB += 1;
        displayForTeamB(scoreTeamB, foulsForB);
    }

    public void foulForB(View view) {
        foulsForB += 1;
        displayForTeamB(scoreTeamB, foulsForB);
    }
    public void reset(View view){
        scoreTeamA = 0;
        scoreTeamB = 0;
        foulsForA = 0;
        foulsForB = 0;
        displayForTeamA(scoreTeamA, foulsForA);
        displayForTeamB(scoreTeamB, foulsForB);
    }
}